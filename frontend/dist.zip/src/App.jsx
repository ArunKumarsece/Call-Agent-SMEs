import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import CreateAgent from './pages/CreateAgent';
import AgentDetail from './pages/AgentDetail';
import EditAgent from './pages/EditAgent';

function Navbar() {
    const location = useLocation();

    return (
        <nav className="navbar">
            <Link to="/" className="navbar-brand">
                <span className="brand-icon">🤖</span>
                VoiceForge AI
            </Link>
            <div className="navbar-links">
                <Link to="/" className={location.pathname === '/' ? 'active' : ''}>
                    Dashboard
                </Link>
                <Link to="/agents/new" className={location.pathname === '/agents/new' ? 'active' : ''}>
                    Create Agent
                </Link>
            </div>
        </nav>
    );
}

function App() {
    return (
        <Router>
            <div className="app-layout">
                <Navbar />
                <main className="app-content">
                    <Routes>
                        <Route path="/" element={<Dashboard />} />
                        <Route path="/agents/new" element={<CreateAgent />} />
                        <Route path="/agents/:id" element={<AgentDetail />} />
                        <Route path="/agents/:id/edit" element={<EditAgent />} />
                    </Routes>
                </main>
            </div>
        </Router>
    );
}

export default App;
