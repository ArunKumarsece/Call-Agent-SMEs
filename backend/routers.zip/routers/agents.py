"""CRUD API routes for Agents."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models import Agent, KnowledgeBase
from schemas import AgentCreate, AgentUpdate, AgentResponse, SDKResponse
from services.sdk_generator import generate_sdk_code
from datetime import datetime, timezone

router = APIRouter(prefix="/api/agents", tags=["agents"])


@router.post("/", response_model=AgentResponse)
async def create_agent(agent: AgentCreate, db: Session = Depends(get_db)):
    """Create a new AI agent."""
    db_agent = Agent(
        name=agent.name,
        role=agent.role,
        description=agent.description,
        system_prompt=agent.system_prompt,
        voice_id=agent.voice_id,
        language=agent.language
    )
    db.add(db_agent)
    db.commit()
    db.refresh(db_agent)

    return AgentResponse(
        id=db_agent.id,
        name=db_agent.name,
        role=db_agent.role,
        description=db_agent.description,
        system_prompt=db_agent.system_prompt,
        voice_id=db_agent.voice_id,
        language=db_agent.language,
        created_at=db_agent.created_at,
        updated_at=db_agent.updated_at,
        kb_count=0
    )


@router.get("/", response_model=list[AgentResponse])
async def list_agents(db: Session = Depends(get_db)):
    """List all agents."""
    agents = db.query(Agent).order_by(Agent.created_at.desc()).all()
    result = []
    for a in agents:
        kb_count = db.query(KnowledgeBase).filter(
            KnowledgeBase.agent_id == a.id
        ).count()
        result.append(AgentResponse(
            id=a.id, name=a.name, role=a.role,
            description=a.description, system_prompt=a.system_prompt,
            voice_id=a.voice_id, language=a.language,
            created_at=a.created_at, updated_at=a.updated_at,
            kb_count=kb_count
        ))
    return result


@router.get("/{agent_id}", response_model=AgentResponse)
async def get_agent(agent_id: str, db: Session = Depends(get_db)):
    """Get a single agent by ID."""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    kb_count = db.query(KnowledgeBase).filter(
        KnowledgeBase.agent_id == agent.id
    ).count()
    return AgentResponse(
        id=agent.id, name=agent.name, role=agent.role,
        description=agent.description, system_prompt=agent.system_prompt,
        voice_id=agent.voice_id, language=agent.language,
        created_at=agent.created_at, updated_at=agent.updated_at,
        kb_count=kb_count
    )


@router.put("/{agent_id}", response_model=AgentResponse)
async def update_agent(agent_id: str, update: AgentUpdate,
                       db: Session = Depends(get_db)):
    """Update an existing agent."""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    update_data = update.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(agent, key, value)

    agent.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(agent)

    kb_count = db.query(KnowledgeBase).filter(
        KnowledgeBase.agent_id == agent.id
    ).count()
    return AgentResponse(
        id=agent.id, name=agent.name, role=agent.role,
        description=agent.description, system_prompt=agent.system_prompt,
        voice_id=agent.voice_id, language=agent.language,
        created_at=agent.created_at, updated_at=agent.updated_at,
        kb_count=kb_count
    )


@router.delete("/{agent_id}")
async def delete_agent(agent_id: str, db: Session = Depends(get_db)):
    """Delete an agent and its knowledge bases."""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    db.delete(agent)
    db.commit()
    return {"message": "Agent deleted successfully", "id": agent_id}


@router.get("/{agent_id}/sdk", response_model=SDKResponse)
async def get_agent_sdk(agent_id: str, db: Session = Depends(get_db)):
    """Get the SDK embed code for an agent."""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    sdk = generate_sdk_code(agent.id, agent.name)
    return SDKResponse(
        agent_id=agent.id,
        agent_name=agent.name,
        html_snippet=sdk["html_snippet"],
        js_config=sdk["js_config"],
        instructions=sdk["instructions"]
    )


@router.post("/{agent_id}/chat")
async def chat_with_agent(agent_id: str, body: dict,
                          db: Session = Depends(get_db)):
    """Text chat with an agent (for testing)."""
    from services.gemini_service import generate_response, get_tanglish_system_prompt
    from services.embeddings import search_knowledge_base

    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    message = body.get("message", "")
    if not message:
        raise HTTPException(status_code=400, detail="Message is required")

    # RAG search
    try:
        results = await search_knowledge_base(message, agent_id, db, top_k=3)
    except Exception as e:
        print(f"RAG search error (non-fatal): {e}")
        results = []
    context = "\n\n".join([r["content"] for r in results]) if results else ""

    system_prompt = get_tanglish_system_prompt(
        agent.system_prompt or "", agent.role
    )

    try:
        response = await generate_response(message, system_prompt, context)
    except Exception as e:
        print(f"❌ Chat error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"AI generation failed: {str(e)}"
        )

    return {
        "response": response,
        "sources": [{"content": r["content"][:100], "score": r["score"]}
                    for r in results]
    }
