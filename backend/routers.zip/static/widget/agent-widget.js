/**
 * ═══════════════════════════════════════════════════════════
 * AI Voice Agent Widget — Embeddable SDK
 * Drop this script into any website to add an AI voice agent.
 * ═══════════════════════════════════════════════════════════
 *
 * Usage:
 *   <script>
 *     window.AgentWidgetConfig = {
 *       agentId: "your-agent-id",
 *       serverUrl: "http://localhost:8000",
 *       theme: "dark",
 *       position: "bottom-right",
 *       title: "Support Agent",
 *       primaryColor: "#6C63FF"
 *     };
 *   </script>
 *   <script src="http://localhost:8000/static/widget/agent-widget.js"></script>
 */
(function () {
    'use strict';

    const config = window.AgentWidgetConfig || {};
    const AGENT_ID = config.agentId || '';
    const SERVER_URL = (config.serverUrl || 'http://localhost:8000').replace(/\/$/, '');
    const THEME = config.theme || 'dark';
    const POSITION = config.position || 'bottom-right';
    const TITLE = config.title || 'AI Assistant';
    const SUBTITLE = config.subtitle || 'Click to start a voice call';
    const PRIMARY_COLOR = config.primaryColor || '#6C63FF';

    if (!AGENT_ID) {
        console.error('[AgentWidget] No agentId provided in AgentWidgetConfig');
        return;
    }

    // ─── Styles ─────────────────────────────────────────
    const isDark = THEME === 'dark';
    const colors = {
        bg: isDark ? '#1A1A3E' : '#FFFFFF',
        bgSecondary: isDark ? '#12122A' : '#F5F5F5',
        text: isDark ? '#F0F0FF' : '#1A1A2E',
        textMuted: isDark ? '#9090B0' : '#666666',
        border: isDark ? 'rgba(108, 99, 255, 0.15)' : 'rgba(0, 0, 0, 0.1)',
        primary: PRIMARY_COLOR,
        danger: '#EF4444',
        userMsg: isDark ? '#4F46E5' : '#E8E5FF',
        agentMsg: isDark ? '#242450' : '#F0F0F0',
    };

    const posStyles = {
        'bottom-right': 'right: 24px; bottom: 24px;',
        'bottom-left': 'left: 24px; bottom: 24px;',
    };

    const css = `
    #agent-widget-fab {
      position: fixed;
      ${posStyles[POSITION] || posStyles['bottom-right']}
      z-index: 99999;
      width: 64px;
      height: 64px;
      border-radius: 50%;
      background: linear-gradient(135deg, ${colors.primary}, #00D9FF);
      border: none;
      cursor: pointer;
      box-shadow: 0 4px 20px rgba(108, 99, 255, 0.4);
      font-size: 28px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.3s ease;
    }
    #agent-widget-fab:hover {
      transform: scale(1.1);
      box-shadow: 0 8px 30px rgba(108, 99, 255, 0.5);
    }
    #agent-widget-panel {
      position: fixed;
      ${POSITION === 'bottom-left' ? 'left: 24px;' : 'right: 24px;'}
      bottom: 100px;
      z-index: 99999;
      width: 380px;
      max-height: 520px;
      background: ${colors.bg};
      border: 1px solid ${colors.border};
      border-radius: 20px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
      display: none;
      flex-direction: column;
      overflow: hidden;
      font-family: 'Inter', -apple-system, sans-serif;
      color: ${colors.text};
    }
    #agent-widget-panel.open { display: flex; animation: awSlideUp 0.3s ease; }
    @keyframes awSlideUp {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .aw-header {
      padding: 16px 20px;
      background: ${isDark ? 'rgba(108, 99, 255, 0.05)' : '#FAFAFA'};
      border-bottom: 1px solid ${colors.border};
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .aw-header-title {
      font-size: 16px;
      font-weight: 700;
      margin: 0;
    }
    .aw-header-sub {
      font-size: 11px;
      color: ${colors.textMuted};
      margin: 2px 0 0;
    }
    .aw-close {
      background: none;
      border: none;
      color: ${colors.textMuted};
      font-size: 20px;
      cursor: pointer;
      padding: 4px;
    }
    .aw-messages {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      min-height: 200px;
      max-height: 300px;
    }
    .aw-msg {
      padding: 10px 14px;
      border-radius: 14px;
      font-size: 13px;
      line-height: 1.5;
      max-width: 85%;
      word-break: break-word;
    }
    .aw-msg-user {
      align-self: flex-end;
      background: ${colors.userMsg};
      color: ${isDark ? 'white' : '#333'};
      border-bottom-right-radius: 4px;
    }
    .aw-msg-agent {
      align-self: flex-start;
      background: ${colors.agentMsg};
      border: 1px solid ${colors.border};
      border-bottom-left-radius: 4px;
    }
    .aw-msg-system {
      align-self: center;
      background: transparent;
      color: ${colors.textMuted};
      font-size: 11px;
      text-align: center;
    }
    .aw-status {
      text-align: center;
      font-size: 12px;
      color: ${colors.textMuted};
      padding: 4px;
    }
    .aw-controls {
      padding: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 16px;
      border-top: 1px solid ${colors.border};
    }
    .aw-mic {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      border: none;
      background: linear-gradient(135deg, ${colors.primary}, #00D9FF);
      color: white;
      font-size: 24px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(108, 99, 255, 0.3);
    }
    .aw-mic:hover { transform: scale(1.05); }
    .aw-mic.recording {
      background: ${colors.danger};
      box-shadow: 0 4px 15px rgba(239, 68, 68, 0.4);
      animation: awPulse 1.2s ease infinite;
    }
    @keyframes awPulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.05); }
    }
    .aw-end {
      padding: 8px 16px;
      border-radius: 20px;
      border: none;
      background: ${colors.danger};
      color: white;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
    .aw-input-row {
      display: flex;
      gap: 8px;
      padding: 0 16px 12px;
    }
    .aw-input-row input {
      flex: 1;
      padding: 8px 12px;
      background: ${colors.bgSecondary};
      border: 1px solid ${colors.border};
      border-radius: 10px;
      color: ${colors.text};
      font-size: 13px;
      outline: none;
      font-family: inherit;
    }
    .aw-input-row button {
      padding: 8px 14px;
      background: ${colors.primary};
      border: none;
      border-radius: 10px;
      color: white;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
  `;

    // ─── Inject Styles ──────────────────────────────────
    const styleEl = document.createElement('style');
    styleEl.textContent = css;
    document.head.appendChild(styleEl);

    // ─── Build DOM ──────────────────────────────────────
    // FAB Button
    const fab = document.createElement('button');
    fab.id = 'agent-widget-fab';
    fab.innerHTML = '🎤';
    fab.setAttribute('aria-label', 'Open AI Voice Agent');
    document.body.appendChild(fab);

    // Panel
    const panel = document.createElement('div');
    panel.id = 'agent-widget-panel';
    panel.innerHTML = `
    <div class="aw-header">
      <div>
        <div class="aw-header-title">${TITLE}</div>
        <div class="aw-header-sub">${SUBTITLE}</div>
      </div>
      <button class="aw-close" id="aw-close">✕</button>
    </div>
    <div class="aw-messages" id="aw-messages"></div>
    <div class="aw-status" id="aw-status">Click the mic to start speaking</div>
    <div class="aw-controls">
      <button class="aw-mic" id="aw-mic">🎤</button>
    </div>
    <div class="aw-input-row">
      <input type="text" id="aw-text-input" placeholder="Or type a message..." />
      <button id="aw-text-send">Send</button>
    </div>
  `;
    document.body.appendChild(panel);

    // ─── State ──────────────────────────────────────────
    let ws = null;
    let mediaRecorder = null;
    let audioChunks = [];
    let isRecording = false;
    let isConnected = false;

    const messagesEl = document.getElementById('aw-messages');
    const statusEl = document.getElementById('aw-status');
    const micBtn = document.getElementById('aw-mic');
    const closeBtn = document.getElementById('aw-close');
    const textInput = document.getElementById('aw-text-input');
    const textSend = document.getElementById('aw-text-send');

    // ─── Events ─────────────────────────────────────────
    fab.addEventListener('click', () => {
        panel.classList.toggle('open');
        if (panel.classList.contains('open')) {
            fab.innerHTML = '✕';
        } else {
            fab.innerHTML = '🎤';
        }
    });

    closeBtn.addEventListener('click', () => {
        panel.classList.remove('open');
        fab.innerHTML = '🎤';
    });

    micBtn.addEventListener('click', toggleRecording);

    textSend.addEventListener('click', sendTextMessage);
    textInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') sendTextMessage();
    });

    // ─── Functions ──────────────────────────────────────
    function connect() {
        const protocol = SERVER_URL.startsWith('https') ? 'wss' : 'ws';
        const host = SERVER_URL.replace(/^https?:\/\//, '');
        ws = new WebSocket(`${protocol}://${host}/ws/call/${AGENT_ID}`);

        ws.onopen = () => {
            isConnected = true;
            statusEl.textContent = 'Connected! Click mic to speak';
            addMsg('system', `Connected to ${TITLE}`);
        };

        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            if (data.type === 'status') statusEl.textContent = data.text;
            else if (data.type === 'transcript') addMsg('user', `🎤 "${data.text}"`);
            else if (data.type === 'response') {
                addMsg('agent', data.text);
                statusEl.textContent = 'Agent responded';
            }
            else if (data.type === 'audio') playAudio(data.data, data.text);
            else if (data.type === 'error') {
                statusEl.textContent = data.text;
                addMsg('system', '⚠️ ' + data.text);
            }
        };

        ws.onclose = () => {
            isConnected = false;
            isRecording = false;
            micBtn.classList.remove('recording');
            statusEl.textContent = 'Disconnected';
        };
    }

    function disconnect() {
        if (ws) { ws.close(); ws = null; }
        if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
        isConnected = false;
        isRecording = false;
        micBtn.classList.remove('recording');
    }

    async function toggleRecording() {
        if (!isConnected) {
            connect();
            return;
        }

        if (isRecording) {
            if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
            isRecording = false;
            micBtn.classList.remove('recording');
            micBtn.innerHTML = '🎤';
            statusEl.textContent = 'Processing...';
        } else {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({
                    audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true }
                });

                audioChunks = [];
                mediaRecorder = new MediaRecorder(stream, {
                    mimeType: MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
                        ? 'audio/webm;codecs=opus' : 'audio/webm'
                });

                mediaRecorder.ondataavailable = (e) => {
                    if (e.data.size > 0) audioChunks.push(e.data);
                };

                mediaRecorder.onstop = () => {
                    stream.getTracks().forEach(t => t.stop());
                    if (audioChunks.length > 0 && ws && ws.readyState === WebSocket.OPEN) {
                        const blob = new Blob(audioChunks, { type: 'audio/webm' });
                        const reader = new FileReader();
                        reader.onloadend = () => {
                            ws.send(JSON.stringify({ type: 'end_turn', fullAudio: reader.result.split(',')[1] }));
                        };
                        reader.readAsDataURL(blob);
                    }
                };

                mediaRecorder.start(250);
                isRecording = true;
                micBtn.classList.add('recording');
                micBtn.innerHTML = '⏹️';
                statusEl.textContent = '🔴 Recording...';
            } catch (err) {
                statusEl.textContent = 'Mic access denied';
            }
        }
    }

    function sendTextMessage() {
        const text = textInput.value.trim();
        if (!text) return;
        textInput.value = '';

        if (isConnected && ws && ws.readyState === WebSocket.OPEN) {
            addMsg('user', text);
            ws.send(JSON.stringify({ type: 'text', text }));
            statusEl.textContent = 'Thinking...';
        } else {
            // REST fallback
            addMsg('user', text);
            statusEl.textContent = 'Thinking...';
            fetch(`${SERVER_URL}/api/agents/${AGENT_ID}/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text }),
            })
                .then(r => r.json())
                .then(data => {
                    addMsg('agent', data.response);
                    statusEl.textContent = 'Agent responded';
                })
                .catch(err => {
                    addMsg('system', '⚠️ ' + err.message);
                    statusEl.textContent = 'Error';
                });
        }
    }

    function addMsg(role, text) {
        const div = document.createElement('div');
        div.className = `aw-msg aw-msg-${role}`;
        div.textContent = text;
        messagesEl.appendChild(div);
        messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    function playAudio(b64, text) {
        try {
            const bytes = atob(b64);
            if (bytes.length > 100) {
                const arr = new Uint8Array(bytes.length);
                for (let i = 0; i < bytes.length; i++) arr[i] = bytes.charCodeAt(i);
                const blob = new Blob([arr], { type: 'audio/mp3' });
                const audio = new Audio(URL.createObjectURL(blob));
                audio.play().catch(() => speak(text));
            } else { speak(text); }
        } catch { speak(text); }
    }

    function speak(text) {
        if ('speechSynthesis' in window) {
            const u = new SpeechSynthesisUtterance(text);
            u.rate = 0.95;
            window.speechSynthesis.speak(u);
        }
    }
})();
