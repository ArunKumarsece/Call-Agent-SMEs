"""WebSocket voice call endpoint with VAD and noise filtering."""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from database import SessionLocal
from models import Agent
from services.gemini_service import (
    generate_response, get_tanglish_system_prompt,
    speech_to_text, text_to_speech
)
from services.embeddings import search_knowledge_base
from services.audio_processor import process_audio_pipeline
import json
import base64
import asyncio
import traceback

router = APIRouter(tags=["voice_call"])


@router.websocket("/ws/call/{agent_id}")
async def voice_call(websocket: WebSocket, agent_id: str):
    """WebSocket endpoint for real-time voice calls with an agent.

    Protocol:
    - Client sends: {"type": "audio", "data": "<base64 audio>"}
    - Client sends: {"type": "end_turn", "fullAudio": "<base64>"} when user stops speaking
    - Client sends: {"type": "text", "text": "..."} for text chat
    - Server sends: {"type": "transcript", "text": "..."} for STT result
    - Server sends: {"type": "response", "text": "..."} for AI response
    - Server sends: {"type": "audio", "data": "<base64>", "text": "..."} for TTS
    - Server sends: {"type": "status", "text": "..."} for status updates
    - Server sends: {"type": "error", "text": "..."} for errors
    """
    await websocket.accept()

    db = SessionLocal()
    try:
        # Validate agent
        agent = db.query(Agent).filter(Agent.id == agent_id).first()
        if not agent:
            await websocket.send_json({
                "type": "error",
                "text": "Agent not found"
            })
            await websocket.close()
            return

        system_prompt = get_tanglish_system_prompt(
            agent.system_prompt or "", agent.role
        )

        conversation_history = []
        audio_buffer = b''

        await websocket.send_json({
            "type": "status",
            "text": f"Connected to {agent.name}. Start speaking or type a message..."
        })

        while True:
            try:
                raw_data = await asyncio.wait_for(
                    websocket.receive_text(), timeout=300
                )  # 5 min timeout
                message = json.loads(raw_data)
                msg_type = message.get("type", "")

                if msg_type == "audio":
                    # Accumulate audio chunks
                    audio_data = message.get("data", "")
                    if audio_data:
                        audio_chunk = base64.b64decode(audio_data)
                        audio_buffer += audio_chunk

                elif msg_type == "end_turn":
                    # Use fullAudio if provided (complete recording blob)
                    full_audio_b64 = message.get("fullAudio", "")

                    if not full_audio_b64 and not audio_buffer:
                        await websocket.send_json({
                            "type": "status",
                            "text": "No audio received. Please try again."
                        })
                        continue

                    await websocket.send_json({
                        "type": "status",
                        "text": "Processing your voice..."
                    })

                    try:
                        # Use the full audio blob for STT (better quality)
                        if full_audio_b64:
                            audio_for_stt = base64.b64decode(full_audio_b64)
                        else:
                            audio_for_stt = audio_buffer

                        audio_buffer = b''  # Reset buffer

                        if len(audio_for_stt) < 100:
                            await websocket.send_json({
                                "type": "status",
                                "text": "Audio too short. Please speak longer."
                            })
                            continue

                        # Speech to Text
                        transcript = await speech_to_text(audio_for_stt)

                        if not transcript:
                            await websocket.send_json({
                                "type": "status",
                                "text": "Could not understand speech. Please try again."
                            })
                            continue

                        await websocket.send_json({
                            "type": "transcript",
                            "text": transcript
                        })

                        # Process like a text message from here
                        await process_and_respond(
                            websocket, transcript, agent, agent_id,
                            system_prompt, conversation_history, db
                        )

                    except Exception as e:
                        print(f"❌ Voice processing error: {e}")
                        traceback.print_exc()
                        await websocket.send_json({
                            "type": "error",
                            "text": f"Voice processing error: {str(e)}"
                        })

                elif msg_type == "text":
                    # Text chat fallback
                    user_text = message.get("text", "").strip()
                    if not user_text:
                        continue

                    print(f"💬 Text message received: {user_text}")

                    try:
                        await process_and_respond(
                            websocket, user_text, agent, agent_id,
                            system_prompt, conversation_history, db
                        )
                    except Exception as e:
                        print(f"❌ Text processing error: {e}")
                        traceback.print_exc()
                        await websocket.send_json({
                            "type": "error",
                            "text": f"Processing error: {str(e)}"
                        })

                elif msg_type == "ping":
                    await websocket.send_json({"type": "pong"})

            except asyncio.TimeoutError:
                await websocket.send_json({
                    "type": "status",
                    "text": "Call timed out due to inactivity."
                })
                break

    except WebSocketDisconnect:
        print(f"WebSocket disconnected for agent {agent_id}")
    except Exception as e:
        print(f"❌ WebSocket error: {e}")
        traceback.print_exc()
        try:
            await websocket.send_json({
                "type": "error",
                "text": str(e)
            })
        except:
            pass
    finally:
        db.close()


async def process_and_respond(
    websocket, user_text, agent, agent_id,
    system_prompt, conversation_history, db
):
    """Shared logic for processing user text and generating AI response."""
    await websocket.send_json({
        "type": "status",
        "text": "Thinking..."
    })

    # RAG search
    try:
        results = await search_knowledge_base(
            user_text, agent_id, db, top_k=3
        )
        context = "\n\n".join(
            [r["content"] for r in results]
        ) if results else ""
    except Exception as e:
        print(f"RAG search error (non-fatal): {e}")
        context = ""
        results = []

    # Generate AI response
    conversation_history.append({
        "role": "user", "content": user_text
    })

    response_text = await generate_response(
        user_text, system_prompt, context,
        conversation_history
    )

    conversation_history.append({
        "role": "assistant", "content": response_text
    })

    await websocket.send_json({
        "type": "response",
        "text": response_text
    })

    # TTS (returns text for client-side synthesis)
    tts_audio = await text_to_speech(response_text, agent.voice_id)

    await websocket.send_json({
        "type": "audio",
        "data": base64.b64encode(tts_audio).decode('utf-8'),
        "text": response_text
    })
