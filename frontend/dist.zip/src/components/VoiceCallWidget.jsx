import { useState, useEffect, useRef } from 'react';
import { createCallWebSocket, agentsAPI } from '../api';

export default function VoiceCallWidget({ agentId, agentName }) {
    const [connected, setConnected] = useState(false);
    const [recording, setRecording] = useState(false);
    const [messages, setMessages] = useState([]);
    const [status, setStatus] = useState('Click the microphone to start a call');
    const [textInput, setTextInput] = useState('');
    const wsRef = useRef(null);
    const mediaRecorderRef = useRef(null);
    const audioChunksRef = useRef([]);
    const messagesEndRef = useRef(null);

    useEffect(() => {
        return () => {
            disconnectCall();
        };
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    function connectCall() {
        const ws = createCallWebSocket(agentId);
        wsRef.current = ws;

        ws.onopen = () => {
            setConnected(true);
            setStatus('Connected! Click mic to speak or type a message');
            addMessage('system', `Connected to ${agentName}`);
        };

        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            switch (data.type) {
                case 'status':
                    setStatus(data.text);
                    break;
                case 'transcript':
                    addMessage('user-transcript', `🎤 You said: "${data.text}"`);
                    break;
                case 'response':
                    addMessage('agent', data.text);
                    setStatus('Agent responded. Click mic to speak again');
                    break;
                case 'audio':
                    // Play audio response (TTS)
                    playAudioResponse(data.data, data.text);
                    break;
                case 'error':
                    setStatus(`Error: ${data.text}`);
                    addMessage('system', `⚠️ ${data.text}`);
                    break;
                case 'pong':
                    break;
            }
        };

        ws.onclose = () => {
            setConnected(false);
            setRecording(false);
            setStatus('Disconnected. Click mic to reconnect.');
        };

        ws.onerror = (err) => {
            console.error('WebSocket error:', err);
            setStatus('Connection error');
        };
    }

    function disconnectCall() {
        if (wsRef.current) {
            wsRef.current.close();
            wsRef.current = null;
        }
        if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
            mediaRecorderRef.current.stop();
        }
        setConnected(false);
        setRecording(false);
    }

    async function toggleRecording() {
        if (!connected) {
            connectCall();
            return;
        }

        if (recording) {
            // Stop recording
            if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
                mediaRecorderRef.current.stop();
            }
            setRecording(false);
            setStatus('Processing your voice...');
        } else {
            // Start recording
            try {
                const stream = await navigator.mediaDevices.getUserMedia({
                    audio: {
                        channelCount: 1,
                        sampleRate: 16000,
                        echoCancellation: true,
                        noiseSuppression: true,
                        autoGainControl: true,
                    }
                });

                audioChunksRef.current = [];
                const mediaRecorder = new MediaRecorder(stream, {
                    mimeType: MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
                        ? 'audio/webm;codecs=opus'
                        : 'audio/webm'
                });

                mediaRecorder.ondataavailable = (e) => {
                    if (e.data.size > 0) {
                        audioChunksRef.current.push(e.data);
                        // Stream chunks to WebSocket
                        const reader = new FileReader();
                        reader.onloadend = () => {
                            if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                                const base64 = reader.result.split(',')[1];
                                wsRef.current.send(JSON.stringify({
                                    type: 'audio',
                                    data: base64,
                                }));
                            }
                        };
                        reader.readAsDataURL(e.data);
                    }
                };

                mediaRecorder.onstop = async () => {
                    stream.getTracks().forEach(track => track.stop());

                    // Send end_turn with full audio
                    if (audioChunksRef.current.length > 0) {
                        const fullBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                        const reader = new FileReader();
                        reader.onloadend = () => {
                            if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                                const base64 = reader.result.split(',')[1];
                                wsRef.current.send(JSON.stringify({
                                    type: 'end_turn',
                                    fullAudio: base64,
                                }));
                            }
                        };
                        reader.readAsDataURL(fullBlob);
                    }
                };

                mediaRecorderRef.current = mediaRecorder;
                mediaRecorder.start(250); // Collect chunks every 250ms
                setRecording(true);
                setStatus('🔴 Recording... Click again to stop');
            } catch (err) {
                console.error('Mic access error:', err);
                setStatus('Microphone access denied. Please allow mic access.');
            }
        }
    }

    function addMessage(role, text) {
        setMessages(prev => [...prev, { role, text, time: new Date() }]);
    }

    function playAudioResponse(base64Audio, text) {
        try {
            // Try playing the audio
            const audioBytes = atob(base64Audio);
            // Check if it's actual audio or fallback text
            if (audioBytes.length > 100) {
                const arrayBuffer = new Uint8Array(audioBytes.length);
                for (let i = 0; i < audioBytes.length; i++) {
                    arrayBuffer[i] = audioBytes.charCodeAt(i);
                }
                const blob = new Blob([arrayBuffer], { type: 'audio/mp3' });
                const url = URL.createObjectURL(blob);
                const audio = new Audio(url);
                audio.play().catch(() => {
                    // Fallback to browser TTS
                    speakText(text);
                });
            } else {
                speakText(text);
            }
        } catch {
            speakText(text);
        }
    }

    function speakText(text) {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.rate = 0.95;
            utterance.pitch = 1;
            window.speechSynthesis.speak(utterance);
        }
    }

    async function handleTextSubmit(e) {
        e.preventDefault();
        if (!textInput.trim()) return;

        if (!connected) {
            // Use REST API for text chat
            addMessage('user', textInput);
            setStatus('Thinking...');
            try {
                const response = await agentsAPI.chat(agentId, textInput);
                addMessage('agent', response.response);
                setStatus('Agent responded');
            } catch (err) {
                addMessage('system', `⚠️ ${err.message}`);
                setStatus('Error getting response');
            }
        } else {
            // Use WebSocket
            addMessage('user', textInput);
            wsRef.current.send(JSON.stringify({
                type: 'text',
                text: textInput,
            }));
            setStatus('Thinking...');
        }
        setTextInput('');
    }

    return (
        <div className="voice-widget" style={{ maxWidth: 600 }}>
            <div className="voice-widget-header">
                <div>
                    <h3 style={{ fontSize: 'var(--font-base)', fontWeight: 700 }}>
                        🧪 Test Call — {agentName}
                    </h3>
                    <span className={`badge ${connected ? 'badge-success' : 'badge-warning'}`} style={{ marginTop: 4 }}>
                        {connected ? '🟢 Connected' : '⚪ Disconnected'}
                    </span>
                </div>
                {connected && (
                    <button className="btn btn-danger btn-sm" onClick={disconnectCall}>
                        📞 End Call
                    </button>
                )}
            </div>

            <div className="voice-widget-body">
                <div className="voice-widget-messages">
                    {messages.length === 0 && (
                        <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 'var(--space-xl)' }}>
                            Start a conversation by clicking the mic or typing a message
                        </div>
                    )}
                    {messages.map((msg, i) => (
                        <div
                            key={i}
                            className={`voice-message ${msg.role === 'user' || msg.role === 'user-transcript' ? 'user' : 'agent'}`}
                            style={msg.role === 'system' ? {
                                alignSelf: 'center',
                                background: 'rgba(108, 99, 255, 0.1)',
                                border: '1px solid var(--border-color)',
                                fontSize: 'var(--font-xs)',
                                color: 'var(--text-secondary)',
                                maxWidth: '100%',
                            } : {}}
                        >
                            {msg.text}
                        </div>
                    ))}
                    <div ref={messagesEndRef} />
                </div>

                <div className="voice-status">{status}</div>

                <div className="voice-controls">
                    <button
                        className={`mic-btn ${recording ? 'recording' : ''}`}
                        onClick={toggleRecording}
                        title={recording ? 'Stop recording' : connected ? 'Start recording' : 'Connect & record'}
                    >
                        {recording ? '⏹️' : '🎤'}
                    </button>
                </div>

                <form className="voice-text-input" onSubmit={handleTextSubmit}>
                    <input
                        value={textInput}
                        onChange={e => setTextInput(e.target.value)}
                        placeholder="Or type a message..."
                    />
                    <button type="submit" className="btn btn-primary btn-sm">Send</button>
                </form>
            </div>
        </div>
    );
}
