"""SQLAlchemy ORM models."""

from sqlalchemy import Column, String, Text, DateTime, ForeignKey, Integer, JSON
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime, timezone
import uuid


def generate_uuid():
    return str(uuid.uuid4())


class Agent(Base):
    __tablename__ = "agents"

    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String(255), nullable=False)
    role = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    system_prompt = Column(Text, nullable=True)
    voice_id = Column(String(100), default="Puck")
    language = Column(String(50), default="tanglish")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    knowledge_bases = relationship("KnowledgeBase", back_populates="agent",
                                   cascade="all, delete-orphan")


class KnowledgeBase(Base):
    __tablename__ = "knowledge_bases"

    id = Column(String, primary_key=True, default=generate_uuid)
    agent_id = Column(String, ForeignKey("agents.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(255), nullable=False)
    kb_type = Column(String(50), nullable=False)  # 'static' or 'dynamic'
    source_url = Column(Text, nullable=True)  # Google Sheets URL for dynamic
    sync_interval = Column(Integer, default=300)  # seconds, for dynamic KB
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    agent = relationship("Agent", back_populates="knowledge_bases")
    entries = relationship("KBEntry", back_populates="knowledge_base",
                          cascade="all, delete-orphan")


class KBEntry(Base):
    __tablename__ = "kb_entries"

    id = Column(String, primary_key=True, default=generate_uuid)
    kb_id = Column(String, ForeignKey("knowledge_bases.id", ondelete="CASCADE"), nullable=False)
    content = Column(Text, nullable=False)
    embedding = Column(JSON, nullable=True)  # stored as JSON array of floats
    source_file = Column(String(255), nullable=True)
    chunk_index = Column(Integer, default=0)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    knowledge_base = relationship("KnowledgeBase", back_populates="entries")
